﻿namespace PoseEstimation
{
    partial class MatrixControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose( bool disposing )
        {
            if ( disposing && ( components != null ) )
            {
                components.Dispose( );
            }
            base.Dispose( disposing );
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent( )
        {
            this.groupBox = new System.Windows.Forms.GroupBox( );
            this.i3_j3_Box = new System.Windows.Forms.TextBox( );
            this.i3_j2_Box = new System.Windows.Forms.TextBox( );
            this.i3_j1_Box = new System.Windows.Forms.TextBox( );
            this.i3_j0_Box = new System.Windows.Forms.TextBox( );
            this.i2_j3_Box = new System.Windows.Forms.TextBox( );
            this.i2_j2_Box = new System.Windows.Forms.TextBox( );
            this.i2_j1_Box = new System.Windows.Forms.TextBox( );
            this.i2_j0_Box = new System.Windows.Forms.TextBox( );
            this.i1_j3_Box = new System.Windows.Forms.TextBox( );
            this.i1_j2_Box = new System.Windows.Forms.TextBox( );
            this.i1_j1_Box = new System.Windows.Forms.TextBox( );
            this.i1_j0_Box = new System.Windows.Forms.TextBox( );
            this.i0_j3_Box = new System.Windows.Forms.TextBox( );
            this.i0_j2_Box = new System.Windows.Forms.TextBox( );
            this.i0_j1_Box = new System.Windows.Forms.TextBox( );
            this.i0_j0_Box = new System.Windows.Forms.TextBox( );
            this.groupBox.SuspendLayout( );
            this.SuspendLayout( );
            // 
            // groupBox
            // 
            this.groupBox.Controls.Add( this.i3_j3_Box );
            this.groupBox.Controls.Add( this.i3_j2_Box );
            this.groupBox.Controls.Add( this.i3_j1_Box );
            this.groupBox.Controls.Add( this.i3_j0_Box );
            this.groupBox.Controls.Add( this.i2_j3_Box );
            this.groupBox.Controls.Add( this.i2_j2_Box );
            this.groupBox.Controls.Add( this.i2_j1_Box );
            this.groupBox.Controls.Add( this.i2_j0_Box );
            this.groupBox.Controls.Add( this.i1_j3_Box );
            this.groupBox.Controls.Add( this.i1_j2_Box );
            this.groupBox.Controls.Add( this.i1_j1_Box );
            this.groupBox.Controls.Add( this.i1_j0_Box );
            this.groupBox.Controls.Add( this.i0_j3_Box );
            this.groupBox.Controls.Add( this.i0_j2_Box );
            this.groupBox.Controls.Add( this.i0_j1_Box );
            this.groupBox.Controls.Add( this.i0_j0_Box );
            this.groupBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox.Location = new System.Drawing.Point( 0, 0 );
            this.groupBox.Name = "groupBox";
            this.groupBox.Size = new System.Drawing.Size( 230, 110 );
            this.groupBox.TabIndex = 0;
            this.groupBox.TabStop = false;
            // 
            // i3_j3_Box
            // 
            this.i3_j3_Box.Location = new System.Drawing.Point( 160, 80 );
            this.i3_j3_Box.Name = "i3_j3_Box";
            this.i3_j3_Box.ReadOnly = true;
            this.i3_j3_Box.Size = new System.Drawing.Size( 50, 20 );
            this.i3_j3_Box.TabIndex = 15;
            // 
            // i3_j2_Box
            // 
            this.i3_j2_Box.Location = new System.Drawing.Point( 110, 80 );
            this.i3_j2_Box.Name = "i3_j2_Box";
            this.i3_j2_Box.ReadOnly = true;
            this.i3_j2_Box.Size = new System.Drawing.Size( 50, 20 );
            this.i3_j2_Box.TabIndex = 14;
            // 
            // i3_j1_Box
            // 
            this.i3_j1_Box.Location = new System.Drawing.Point( 60, 80 );
            this.i3_j1_Box.Name = "i3_j1_Box";
            this.i3_j1_Box.ReadOnly = true;
            this.i3_j1_Box.Size = new System.Drawing.Size( 50, 20 );
            this.i3_j1_Box.TabIndex = 13;
            // 
            // i3_j0_Box
            // 
            this.i3_j0_Box.Location = new System.Drawing.Point( 10, 80 );
            this.i3_j0_Box.Name = "i3_j0_Box";
            this.i3_j0_Box.ReadOnly = true;
            this.i3_j0_Box.Size = new System.Drawing.Size( 50, 20 );
            this.i3_j0_Box.TabIndex = 12;
            // 
            // i2_j3_Box
            // 
            this.i2_j3_Box.Location = new System.Drawing.Point( 160, 60 );
            this.i2_j3_Box.Name = "i2_j3_Box";
            this.i2_j3_Box.ReadOnly = true;
            this.i2_j3_Box.Size = new System.Drawing.Size( 50, 20 );
            this.i2_j3_Box.TabIndex = 11;
            // 
            // i2_j2_Box
            // 
            this.i2_j2_Box.Location = new System.Drawing.Point( 110, 60 );
            this.i2_j2_Box.Name = "i2_j2_Box";
            this.i2_j2_Box.ReadOnly = true;
            this.i2_j2_Box.Size = new System.Drawing.Size( 50, 20 );
            this.i2_j2_Box.TabIndex = 10;
            // 
            // i2_j1_Box
            // 
            this.i2_j1_Box.Location = new System.Drawing.Point( 60, 60 );
            this.i2_j1_Box.Name = "i2_j1_Box";
            this.i2_j1_Box.ReadOnly = true;
            this.i2_j1_Box.Size = new System.Drawing.Size( 50, 20 );
            this.i2_j1_Box.TabIndex = 9;
            // 
            // i2_j0_Box
            // 
            this.i2_j0_Box.Location = new System.Drawing.Point( 10, 60 );
            this.i2_j0_Box.Name = "i2_j0_Box";
            this.i2_j0_Box.ReadOnly = true;
            this.i2_j0_Box.Size = new System.Drawing.Size( 50, 20 );
            this.i2_j0_Box.TabIndex = 8;
            // 
            // i1_j3_Box
            // 
            this.i1_j3_Box.Location = new System.Drawing.Point( 160, 40 );
            this.i1_j3_Box.Name = "i1_j3_Box";
            this.i1_j3_Box.ReadOnly = true;
            this.i1_j3_Box.Size = new System.Drawing.Size( 50, 20 );
            this.i1_j3_Box.TabIndex = 7;
            // 
            // i1_j2_Box
            // 
            this.i1_j2_Box.Location = new System.Drawing.Point( 110, 40 );
            this.i1_j2_Box.Name = "i1_j2_Box";
            this.i1_j2_Box.ReadOnly = true;
            this.i1_j2_Box.Size = new System.Drawing.Size( 50, 20 );
            this.i1_j2_Box.TabIndex = 6;
            // 
            // i1_j1_Box
            // 
            this.i1_j1_Box.Location = new System.Drawing.Point( 60, 40 );
            this.i1_j1_Box.Name = "i1_j1_Box";
            this.i1_j1_Box.ReadOnly = true;
            this.i1_j1_Box.Size = new System.Drawing.Size( 50, 20 );
            this.i1_j1_Box.TabIndex = 5;
            // 
            // i1_j0_Box
            // 
            this.i1_j0_Box.Location = new System.Drawing.Point( 10, 40 );
            this.i1_j0_Box.Name = "i1_j0_Box";
            this.i1_j0_Box.ReadOnly = true;
            this.i1_j0_Box.Size = new System.Drawing.Size( 50, 20 );
            this.i1_j0_Box.TabIndex = 4;
            // 
            // i0_j3_Box
            // 
            this.i0_j3_Box.Location = new System.Drawing.Point( 160, 20 );
            this.i0_j3_Box.Name = "i0_j3_Box";
            this.i0_j3_Box.ReadOnly = true;
            this.i0_j3_Box.Size = new System.Drawing.Size( 50, 20 );
            this.i0_j3_Box.TabIndex = 3;
            // 
            // i0_j2_Box
            // 
            this.i0_j2_Box.Location = new System.Drawing.Point( 110, 20 );
            this.i0_j2_Box.Name = "i0_j2_Box";
            this.i0_j2_Box.ReadOnly = true;
            this.i0_j2_Box.Size = new System.Drawing.Size( 50, 20 );
            this.i0_j2_Box.TabIndex = 2;
            // 
            // i0_j1_Box
            // 
            this.i0_j1_Box.Location = new System.Drawing.Point( 60, 20 );
            this.i0_j1_Box.Name = "i0_j1_Box";
            this.i0_j1_Box.ReadOnly = true;
            this.i0_j1_Box.Size = new System.Drawing.Size( 50, 20 );
            this.i0_j1_Box.TabIndex = 1;
            // 
            // i0_j0_Box
            // 
            this.i0_j0_Box.Location = new System.Drawing.Point( 10, 20 );
            this.i0_j0_Box.Name = "i0_j0_Box";
            this.i0_j0_Box.ReadOnly = true;
            this.i0_j0_Box.Size = new System.Drawing.Size( 50, 20 );
            this.i0_j0_Box.TabIndex = 0;
            // 
            // MatrixControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF( 6F, 13F );
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add( this.groupBox );
            this.Name = "MatrixControl";
            this.Size = new System.Drawing.Size( 230, 110 );
            this.Load += new System.EventHandler( this.MatrixControl_Load );
            this.groupBox.ResumeLayout( false );
            this.groupBox.PerformLayout( );
            this.ResumeLayout( false );

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox;
        private System.Windows.Forms.TextBox i0_j0_Box;
        private System.Windows.Forms.TextBox i3_j3_Box;
        private System.Windows.Forms.TextBox i3_j2_Box;
        private System.Windows.Forms.TextBox i3_j1_Box;
        private System.Windows.Forms.TextBox i3_j0_Box;
        private System.Windows.Forms.TextBox i2_j3_Box;
        private System.Windows.Forms.TextBox i2_j2_Box;
        private System.Windows.Forms.TextBox i2_j1_Box;
        private System.Windows.Forms.TextBox i2_j0_Box;
        private System.Windows.Forms.TextBox i1_j3_Box;
        private System.Windows.Forms.TextBox i1_j2_Box;
        private System.Windows.Forms.TextBox i1_j1_Box;
        private System.Windows.Forms.TextBox i1_j0_Box;
        private System.Windows.Forms.TextBox i0_j3_Box;
        private System.Windows.Forms.TextBox i0_j2_Box;
        private System.Windows.Forms.TextBox i0_j1_Box;
    }
}
