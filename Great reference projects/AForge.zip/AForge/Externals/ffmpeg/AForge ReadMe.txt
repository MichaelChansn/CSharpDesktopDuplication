The folder contains files from Sared and Dev packages of FFMPEG 32-bit build taken from
http://ffmpeg.zeranoe.com/builds/
Note: few files which are not used by AForge.NET were removed to save space.

Please, refer to README.txt file for details about FFMPEG build.
